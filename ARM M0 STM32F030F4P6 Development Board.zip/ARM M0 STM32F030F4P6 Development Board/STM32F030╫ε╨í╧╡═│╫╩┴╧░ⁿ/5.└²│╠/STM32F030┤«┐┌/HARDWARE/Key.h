void KeyInit(void);
